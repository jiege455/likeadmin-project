<?php
namespace app\api\logic;

use app\common\logic\BaseLogic;
use app\common\model\notice\SystemNotice;
use think\facade\Db;

class NoticeLogic extends BaseLogic
{
    /**
     * @notes 获取系统公告列表
     * @return array
     * @author TraeAI
     */
    public static function getSystemNoticeList($limit = 5)
    {
        // 确保 limit 是合理的数字
        $limit = max(1, min(20, intval($limit)));
        
        // 假设表名是 la_system_notice，模型应该是 app\common\model\notice\SystemNotice
        // 如果没有模型，直接用 Db 查询
        // 这里先尝试用 Db 查询，因为不确定 SystemNotice 模型是否存在
        
        $lists = Db::name('system_notice')
            ->where('is_show', 1)
            ->where('delete_time', null)
            ->order('sort', 'desc')
            ->order('id', 'desc')
            ->limit($limit)
            ->select()
            ->toArray();
            
        return $lists;
    }
}
