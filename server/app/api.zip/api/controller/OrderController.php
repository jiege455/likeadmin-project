<?php

namespace app\api\controller;

use think\facade\Db;

class OrderController extends BaseApiController
{
    /**
     * 订单列表
     */
    public function lists()
    {
        $type = $this->request->get('type', 1); // 1-单料(文章), 2-包时(课程/会员)
        $page = $this->request->get('page', 1);
        $limit = $this->request->get('limit', 10);
        $userId = $this->userId;

        // 暂时返回空数据，等表结构确定后再写查询逻辑
        $lists = [];

        return $this->data([
            'lists' => $lists,
            'page' => $page,
            'count' => 0,
            'page_no' => $page,
            'page_size' => $limit
        ]);
    }
}
