<?php

namespace app\api\controller;

use think\facade\Db;

class DistributionController extends BaseApiController
{
    /**
     * 分销中心首页数据
     */
    public function index()
    {
        $userId = $this->userId;
        $user = Db::name('user')->where('id', $userId)->find();

        // 计算今日佣金（这里假设 earnings 是实时更新的，实际应查流水表）
        // $todayCommission = Db::name('account_log')
        //    ->where('user_id', $userId)
        //    ->where('change_type', 1) // 假设1是增加
        //    ->whereDay('create_time')
        //    ->sum('change_amount');
        
        // 统计邀请人数
        $todayInviteCount = Db::name('user')
            ->where('inviter_id', $userId)
            ->whereDay('create_time')
            ->count();
            
        $totalInviteCount = Db::name('user')
            ->where('inviter_id', $userId)
            ->count();

        return $this->data([
            'total_commission' => $user['earnings'] ?? '0.00', // 累计佣金
            'able_commission' => $user['earnings'] ?? '0.00',  // 可提现
            'wait_commission' => '0.00', // 待结算
            'frozen_commission' => '0.00', // 冻结
            'today_commission' => '0.00', // 今日
            'today_invite_count' => $todayInviteCount, // 今日邀请
            'total_invite_count' => $totalInviteCount, // 累计邀请
        ]);
    }

    /**
     * 获取推广海报信息
     */
    public function poster()
    {
        $userId = $this->userId;
        // 这里返回简单的推广链接，实际前端可以使用 qrcode 组件生成二维码
        // 链接格式：/pages/index/index?invite_code=USER_ID
        $inviteLink = '/pages/index/index?invite_code=' . $userId;
        
        return $this->data([
            'invite_link' => $inviteLink,
            'invite_code' => $userId, // 简单用user_id作为邀请码
            'poster_bg' => '', // 可以在后台配置默认背景图
        ]);
    }

    /**
     * 分销记录
     */
    public function lists()
    {
        // 暂时返回空
        return $this->data([
            'lists' => [],
            'count' => 0,
            'page_no' => 1,
            'page_size' => 10
        ]);
    }
}
