<?php
namespace app\api\controller\merchant;

use app\api\controller\BaseApiController;
use think\facade\Db;

class ArticleController extends BaseApiController
{
    /**
     * 商户文章列表
     */
    public function lists()
    {
        $userId = $this->userId;
        // 先找商户ID
        $merchant = Db::name('merchant')->where('user_id', $userId)->find();
        
        if (!$merchant) {
            return $this->fail('您还不是商户');
        }

        $lists = Db::name('article')
            ->where('merchant_id', $merchant['id'])
            ->where('delete_time', null)
            ->order('create_time', 'desc')
            ->page($this->request->get('page', 1), $this->request->get('limit', 10))
            ->select()
            ->toArray();
            
        // 处理图片路径
        foreach ($lists as &$item) {
             $item['create_time'] = date('Y-m-d H:i', $item['create_time']);
        }

        return $this->data([
            'lists' => $lists,
            'count' => 0 // 暂时不查总数
        ]);
    }

    /**
     * 发布/编辑文章
     */
    public function save()
    {
        $post = $this->request->post();
        $userId = $this->userId;
        $merchant = Db::name('merchant')->where('user_id', $userId)->find();

        if (!$merchant) {
            return $this->fail('您还不是商户');
        }
        
        if (empty($post['title']) || empty($post['content'])) {
            return $this->fail('标题和内容不能为空');
        }

        $data = [
            'title' => $post['title'],
            'cid' => $post['cid'] ?? 1, // 默认为分类ID 1
            'desc' => $post['desc'] ?? '',
            'content' => $post['content'],
            'image' => $post['image'] ?? '',
            'price' => $post['price'] ?? 0,
            'commission_ratio' => $post['commission_ratio'] ?? 0, // 分销比例
            'merchant_id' => $merchant['id'],
            'is_show' => 1,
            'audit_status' => 0, // 默认待审核
            'update_time' => time()
        ];

        if (empty($post['id'])) {
            $data['create_time'] = time();
            Db::name('article')->insert($data);
        } else {
            Db::name('article')->where('id', $post['id'])->where('merchant_id', $merchant['id'])->update($data);
        }

        return $this->success('提交成功，等待审核');
    }

    /**
     * 删除文章
     */
    public function del()
    {
        $id = $this->request->post('id');
        $userId = $this->userId;
        $merchant = Db::name('merchant')->where('user_id', $userId)->find();
        
        if (!$merchant) return $this->fail('无权操作');

        Db::name('article')
            ->where('id', $id)
            ->where('merchant_id', $merchant['id'])
            ->update(['delete_time' => time()]);

        return $this->success('删除成功');
    }
}
