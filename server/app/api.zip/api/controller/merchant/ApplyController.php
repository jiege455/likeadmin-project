<?php

namespace app\api\controller\merchant;

use app\api\controller\BaseApiController;
use think\facade\Db;
use app\common\service\EmailService;

class ApplyController extends BaseApiController
{
    /**
     * 提交入驻申请
     */
    public function add()
    {
        $post = $this->request->post();
        $userId = $this->userId;

        // 验证必填
        if (empty($post['name']) || empty($post['mobile'])) {
            return $this->fail('请填写完整信息');
        }

        // 检查是否已申请
        $exist = Db::name('merchant_apply')
            ->where('user_id', $userId)
            ->where('status', 0) // 待审核
            ->find();

        if ($exist) {
            return $this->fail('您已有申请在审核中，请勿重复提交');
        }

        // 插入申请
        Db::name('merchant_apply')->insert([
            'user_id' => $userId,
            'name' => $post['name'],
            'mobile' => $post['mobile'],
            'desc' => $post['desc'] ?? '',
            'status' => 0,
            'create_time' => time(),
            'update_time' => time()
        ]);

        // 发送邮件通知管理员
        try {
            EmailService::sendToAdmin(
                '新商户入驻申请提醒',
                "有新的商户申请入驻！<br>商户名称：{$post['name']}<br>联系电话：{$post['mobile']}<br>请及时登录后台审核。"
            );
        } catch (\Exception $e) {
            // 邮件发送失败不影响流程
        }

        return $this->success('申请提交成功');
    }

    /**
     * 获取申请详情/状态
     */
    public function detail()
    {
        $userId = $this->userId;
        $info = Db::name('merchant_apply')
            ->where('user_id', $userId)
            ->order('id', 'desc')
            ->find();

        return $this->data($info);
    }
}
