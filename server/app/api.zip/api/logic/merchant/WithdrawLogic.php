<?php
namespace app\api\logic\merchant;

use app\common\logic\BaseLogic;
use app\common\model\finance\WithdrawApply;
use app\common\model\merchant\Merchant;
use think\facade\Db;

class WithdrawLogic extends BaseLogic
{
    /**
     * @notes 申请提现
     * @param $userId
     * @param $params
     * @return bool
     * @author 杰哥
     * @date 2026-02-01
     */
    public static function apply($userId, $params)
    {
        // 参数验证
        $money = $params['money'] ?? 0;
        $type = $params['type'] ?? WithdrawApply::TYPE_BANK;
        $accountInfo = $params['account_info'] ?? [];

        if ($money <= 0) {
            self::$error = '提现金额必须大于0';
            return false;
        }

        $merchant = Merchant::where('user_id', $userId)->find();
        if (!$merchant) {
            self::$error = '非商家账号';
            return false;
        }

        if ($merchant->money < $money) {
            self::$error = '余额不足';
            return false;
        }

        // 启动事务
        Db::startTrans();
        try {
            // 扣除余额
            $merchant->money = bcsub($merchant->money, $money, 2);
            $merchant->save();

            // 创建提现记录
            WithdrawApply::create([
                'merchant_id' => $merchant->id,
                'money' => $money,
                'left_money' => $merchant->money,
                'type' => $type,
                'account_info' => is_array($accountInfo) ? json_encode($accountInfo, JSON_UNESCAPED_UNICODE) : $accountInfo,
                'status' => WithdrawApply::STATUS_WAIT,
                'create_time' => time(),
                'update_time' => time(),
            ]);

            Db::commit();
            return true;
        } catch (\Exception $e) {
            Db::rollback();
            self::$error = $e->getMessage();
            return false;
        }
    }

    /**
     * @notes 提现列表
     * @param $userId
     * @param $params
     * @return array
     * @author 杰哥
     * @date 2026-02-01
     */
    public static function lists($userId, $params)
    {
        $merchant = Merchant::where('user_id', $userId)->find();
        if (!$merchant) {
            return ['lists' => [], 'count' => 0, 'page_no' => 1, 'page_size' => 10];
        }

        $where = [['merchant_id', '=', $merchant->id]];
        
        $count = WithdrawApply::where($where)->count();
        $lists = WithdrawApply::where($where)
            ->page($params['page_no'] ?? 1, $params['page_size'] ?? 10)
            ->order('id', 'desc')
            ->select()
            ->append(['status_desc', 'type_desc'])
            ->toArray();

        return [
            'lists' => $lists,
            'count' => $count,
            'page_no' => $params['page_no'] ?? 1,
            'page_size' => $params['page_size'] ?? 10,
        ];
    }

    /**
     * @notes 提现详情
     * @param $userId
     * @param $id
     * @return array|\think\Model|null
     * @author 杰哥
     * @date 2026-02-01
     */
    public static function detail($userId, $id)
    {
        $merchant = Merchant::where('user_id', $userId)->find();
        if (!$merchant) return null;

        return WithdrawApply::where('id', $id)
            ->where('merchant_id', $merchant->id)
            ->append(['status_desc', 'type_desc'])
            ->find();
    }

    /**
     * @notes 获取提现配置
     * @return array
     * @author 杰哥
     * @date 2026-02-01
     */
    public static function config()
    {
        // 这里可以读取系统配置，暂时硬编码
        return [
            'min_money' => 1,
            'fee_rate' => 0,
            'type' => [
                ['id' => WithdrawApply::TYPE_WECHAT, 'name' => '微信零钱'],
                ['id' => WithdrawApply::TYPE_ALIPAY, 'name' => '支付宝'],
                ['id' => WithdrawApply::TYPE_BANK, 'name' => '银行卡'],
            ]
        ];
    }

    /**
     * @notes 获取商家信息(余额)
     * @param $userId
     * @return array|null
     * @author 杰哥
     * @date 2026-02-01
     */
    public static function info($userId)
    {
        $merchant = Merchant::where('user_id', $userId)->find();
        if (!$merchant) return null;
        return [
            'money' => $merchant->money,
        ];
    }
}
