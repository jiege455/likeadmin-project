<?php

namespace app\api\controller;

use app\common\model\merchant\Merchant;
use app\common\model\user\UserFollowMerchant;
use think\facade\Db;

class MerchantController extends BaseApiController
{
    /**
     * 关注/取消关注商家
     */
    public function follow()
    {
        $merchantId = $this->request->post('merchant_id');
        $userId = $this->userId;

        if (empty($merchantId)) {
            return $this->fail('参数错误');
        }

        $exist = Db::name('user_follow_merchant')
            ->where(['user_id' => $userId, 'merchant_id' => $merchantId])
            ->find();

        if ($exist) {
            // 取消关注
            Db::name('user_follow_merchant')->delete($exist['id']);
            return $this->success('已取消关注');
        } else {
            // 关注
            Db::name('user_follow_merchant')->insert([
                'user_id' => $userId,
                'merchant_id' => $merchantId,
                'create_time' => time()
            ]);
            return $this->success('关注成功');
        }
    }

    /**
     * 商户详情
     */
    public function detail()
    {
        $userId = $this->userId;
        $merchant = Db::name('merchant')->where('user_id', $userId)->find();
        
        if (!$merchant) {
            return $this->fail('您还不是商户');
        }
        
        return $this->data($merchant);
    }

    /**
     * 修改商户资料
     */
    public function edit()
    {
        $post = $this->request->post();
        $userId = $this->userId;
        $merchant = Db::name('merchant')->where('user_id', $userId)->find();

        if (!$merchant) {
            return $this->fail('您还不是商户');
        }

        $data = [];
        if (isset($post['name'])) $data['name'] = $post['name'];
        if (isset($post['image'])) $data['image'] = $post['image'];
        if (isset($post['desc'])) $data['desc'] = $post['desc'];
        
        if (empty($data)) {
            return $this->fail('没有要修改的内容');
        }

        $data['update_time'] = time();
        Db::name('merchant')->where('id', $merchant['id'])->update($data);

        return $this->success('修改成功');
    }

    /**
     * 我的关注列表
     */
    public function followLists()
    {
        $userId = $this->userId;
        $lists = Db::name('user_follow_merchant')
            ->alias('f')
            ->join('merchant m', 'f.merchant_id = m.id')
            ->where('f.user_id', $userId)
            ->field('f.id, f.merchant_id, f.is_push, m.name, m.desc, m.image')
            ->select()
            ->toArray();

        return $this->data($lists);
    }
}
