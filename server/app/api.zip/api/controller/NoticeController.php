<?php
namespace app\api\controller;

use app\api\logic\NoticeLogic;

class NoticeController extends BaseApiController
{
    public array $notNeedLogin = ['system'];

    /**
     * @notes 获取系统公告
     * @return \think\response\Json
     * @author TraeAI
     */
    public function system()
    {
        $limit = $this->request->get('limit', 5);
        $result = NoticeLogic::getSystemNoticeList($limit);
        return $this->data($result);
    }
}
