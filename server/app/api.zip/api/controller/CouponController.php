<?php

namespace app\api\controller;

use think\facade\Db;

class CouponController extends BaseApiController
{
    /**
     * 领券中心列表
     */
    public function lists()
    {
        $userId = $this->userId;
        
        $lists = Db::name('coupon')
            ->where('status', 1)
            ->where('delete_time', null)
            ->where('send_count', '<', Db::raw('total_count'))
            ->order('create_time', 'desc')
            ->select()
            ->toArray();

        foreach ($lists as &$item) {
            // 检查用户是否已领取
            $isGet = Db::name('user_coupon')
                ->where('user_id', $userId)
                ->where('coupon_id', $item['id'])
                ->find();
            $item['is_get'] = $isGet ? 1 : 0;
            
            $item['use_time_desc'] = $item['use_time_type'] == 1 
                ? date('Y-m-d', $item['use_time_start']) . ' ~ ' . date('Y-m-d', $item['use_time_end'])
                : '领取后' . $item['use_days'] . '天内有效';
        }

        return $this->data($lists);
    }

    /**
     * 我的优惠券
     */
    public function my()
    {
        $userId = $this->userId;
        $status = $this->request->get('status', 0); // 0-未使用, 1-已使用, 2-已过期

        $lists = Db::name('user_coupon')
            ->alias('uc')
            ->join('coupon c', 'uc.coupon_id = c.id')
            ->where('uc.user_id', $userId)
            ->where('uc.status', $status)
            ->field('uc.*, c.name, c.use_time_type, c.use_days')
            ->order('uc.id', 'desc')
            ->select()
            ->toArray();

        return $this->data($lists);
    }

    /**
     * 领取优惠券
     */
    public function get()
    {
        $id = $this->request->post('id');
        $userId = $this->userId;

        $coupon = Db::name('coupon')->find($id);
        if (!$coupon || $coupon['status'] != 1 || $coupon['delete_time']) {
            return $this->fail('优惠券不存在或已失效');
        }

        if ($coupon['send_count'] >= $coupon['total_count']) {
            return $this->fail('优惠券已抢光');
        }

        $exist = Db::name('user_coupon')
            ->where('user_id', $userId)
            ->where('coupon_id', $id)
            ->find();
        if ($exist) {
            return $this->fail('您已领取过该优惠券');
        }

        // 计算有效期
        $startTime = time();
        $endTime = 0;
        if ($coupon['use_time_type'] == 1) {
            $startTime = $coupon['use_time_start'];
            $endTime = $coupon['use_time_end'];
        } else {
            $endTime = strtotime("+{$coupon['use_days']} days");
        }

        Db::startTrans();
        try {
            Db::name('user_coupon')->insert([
                'user_id' => $userId,
                'coupon_id' => $id,
                'money' => $coupon['money'],
                'condition_money' => $coupon['condition_money'],
                'use_time_start' => $startTime,
                'use_time_end' => $endTime,
                'status' => 0,
                'create_time' => time()
            ]);

            Db::name('coupon')->where('id', $id)->inc('send_count')->update();
            Db::commit();
            return $this->success('领取成功');
        } catch (\Exception $e) {
            Db::rollback();
            return $this->fail('领取失败');
        }
    }
}
